from colorama import Fore,Back
def main():
    print(Fore.RED + Back.GREEN +  "Hello!")


if __name__ == '__main__':
    main()
